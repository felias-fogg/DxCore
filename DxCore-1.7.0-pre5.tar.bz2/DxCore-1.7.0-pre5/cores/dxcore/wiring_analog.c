/*  OBLIGATORY LEGAL BOILERPLATE
 This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation;
 either version 2.1 of the License, or (at your option) any later version. This library is distributed in the hope that it will be useful, but
 WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 See the GNU Lesser General Public License for more details. You should have received a copy of the GNU Lesser General Public License along with this library;
 if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*//*
  wiring_analog.c - analog input and output
  Servo.h - Interrupt driven Servo library for Arduino using 16 bit timers- Version 2
  Copyright (c) 2005-2006 David A. Mellis, modified 2010 by David Sproul,
  and at least one other individual, since *someone* ported it to "megaavr"
  (aka, modern AVR), and it wasn't me. Finally, Since megaTinyCore was released
  in 2018 this has been extensively modified first for mTC, and then later for DxC
  by Spence Konde (2018-2023).

  This file is included with megaTinyCore and DxCore; note that unlike some files,
  but like most of the "core" files, while some pieces of this code have been shared
  between the two, and DxC was forked from mTC, the differing demands of the two platforms
  are such that an omnibus file is not tenable.
*/


#include "wiring_private.h"
#include "pins_arduino.h"
#include "Arduino.h"
#include <avr/pgmspace.h>




#if __AVR_ARCH__ == 103
  #define _prefix const
  #define _refmethod(x) (x)
#else
  #define _prefix const PROGMEM
  #define _refmethod(x) (pgm_read_byte_near(&x))
#endif


#if defined(VREF_ADC0REF)
  #define _acref_to_c _acref_to_c
  inline __attribute__((always_inline))uint8_t _adcref_to_c(uint8_t refval) {
    refval &= 0x07;
    uint8_t r = refval;// r = refval = 00000xxx
    _swap(refval); //now is 0xxx0000 in refval
    return (r | refval); // which will be the correct value of the new-style constants, 0xxx0xxx
  }
#else
  _prefix uint8_t  _acreftab[8] = {INTERNAL1V024,   INTERNAL2V048, INTERNAL4V096,   INTERNAL2V500, NOT_A_REFERENCE, VDD, EXTERNAL, NOT_A_REFERENCE};
  _prefix uint8_t _adcreftab[8] = {          VDD, NOT_A_REFERENCE,      EXTERNAL, NOT_A_REFERENCE,   INTERNAL1V024,  INTERNAL2V048, INTERNAL4V096, INTERNAL2V500};

  inline __attribute__((always_inline))uint8_t _acref_to_c(uint8_t refval) {
    refval &= 0x07;
    return _refmethod(_acreftab[refval]);
  }
  inline __attribute__((always_inline))uint8_t _adcref_to_c(uint8_t refval) {
    refval &= 0x07;
    return _refmethod(_adcreftab[refval]);
  }
#endif
#define SINGLE_ENDED 254

/* magic value passed as the negative pin to tell the _analogReadEnh() (which implements both th new ADC
 * functions) to tell them what kind of mode it's to be used in. This also helps with providing useful and accurate
 * error messages and codes at runtime, since we have no other way to report such.
 */


/* check_valid_x functions are inline functions which return no value and generate no code in the compiled binary.
  All code is guarded by __builtin_constant_p(x) which returns true IFF x is a compile time known constant that
  will be subject to constant folding later on. So none of this goes in the binary - it is instead used to generate
  errors during compilation when user code asks the hardware to do something nonsensical - say, reading from something
  that isn't a pin, or passed the arguments of something in the wrong order. Since AVRs are sufficiently resource
  constrained that the overhead of detecting and handling errors at runtime is prohibitive, these "silly" programming
  errors would otherwise result in wrong behavior and no error to indicate what is wrong, and only the wrong behavior
  to go on.
  */

/* These essentially use one implementation for all the parts */
inline __attribute__((always_inline)) void check_valid_analog_pin(pin_size_t pin) {
  if (__builtin_constant_p(pin)) {
    if (
    #if defined(ADC_TEMPERATURE)
        pin != ADC_TEMPERATURE &&
    #endif
    #if defined(ADC_GROUND)
        pin != ADC_GROUND &&
    #endif
    #if defined(ADC_DACREF0)
        pin != ADC_DACREF0 &&
    #endif
    #if defined(ADC_DACREF1)
        pin != ADC_DACREF1 &&
    #endif
    #if defined(ADC_DACREF2)
        pin != ADC_DACREF2 &&
    #endif
    #if defined(ADC_VDDDIV10)
        pin != ADC_VDDDIV10 &&
    #endif
    #if defined(ADC_VDDIO2DIV10)
        pin != ADC_VDDIO2DIV10 &&
    #endif
    #if defined(ADC_DAC0) // 1-series
        pin != ADC_DAC0 &&
    #endif
        true)
    { // if it is one of those constants, we know it is valid. Otherwise, make sure it's a valid channel.
      if (pin > 0x80) { // given as a channel, not a pin, but not one of the special inputs???
        pin &= 0x7f;
        if (pin > ADC_MAXIMUM_PIN_CHANNEL)
          badArg("analogRead called with constant channel number which is neither a valid internal source nor an analog pin"); // There is no correct way to read something that isn't an input on the chip.
      }
      pin = digitalPinToAnalogInput(pin);
      if (pin == NOT_A_PIN) {
        badArg("analogRead called with constant pin that is only capable of digital input.");
      }
    }
  }
}

inline __attribute__((always_inline)) void check_valid_analog_ref(uint8_t mode) {
  if (__builtin_constant_p(mode)) {
    if (!(mode == EXTERNAL || mode == VDD || mode == INTERNAL1V024 || mode == INTERNAL2V048 || mode == INTERNAL4V1 || mode == INTERNAL2V5))
      badArg("analogReference called with argument that is not a valid analog reference");
  }
}


inline __attribute__((always_inline)) void check_valid_enh_res(uint8_t res) {
  if (__builtin_constant_p(res)) {
    if (res < 0x80) {
      if (res < 8) {
        badArg("When a resolution is passed to analogReadEnh, it must be at least the minimum native resolution (8 bits)"); //If you want fewer bits, shift it yourself.
      } else if (res > ADC_MAX_OVERSAMPLED_RESOLUTION) {
        badArg("The highest resolution obtainable on these parts through oversampling and decimation with a single ADC operation 13 bits on 0/1-series, DU, and SD, 15 on Dx-series, and 17  or 17 on 2-series");
      }
    } else {
      #if defined(ADC0_TEMP2) /* check_valid_enh_res is different with the new ADC*/
        if ((res & 0x7F) > 0x0A)
      #else /* the old ADC */
        if ((res & 0x7F) > 0x06)
      #endif /* end ADC version conditional valid enh res */
      {
        badArg("Accumulation number invalid - use one of the ADC_ACC_# constants for raw (undecimated) accumulated readings.");
      }
    }
  }
}

inline __attribute__((always_inline)) void check_valid_resolution(uint8_t res) {
  if (__builtin_constant_p(res))
  #if defined(ADC0_TEMP2) /* check_valid_resolution is different with the new ADC*/
    if (res != 8 && res != 10 && res != 12) {
      badArg("analogReadResolution called with invalid argument - valid options are 8, 12, or 10 (compatibility mode).");
    }
  #elif defined(ADC_LOWLAT_bm) //lowlat but small temp reg = DU/SD
    if (res != 8 && res != 10){
      badArg("analogReadResolution called with invalid argument - valid options are 8 or 10.");
    }
  #else
    if (res != 8 && res != 10 && res != 12) {
      badArg("analogReadResolution called with invalid argument - valid options are 8, 12, or 10 (compatibility mode).");
    }
  #endif /* end ADC version conditional valid res*/
}


#ifdef DAC0 /* Only DAC-bearing parts get this */
  void DACReference(uint8_t mode) {
    if (__builtin_constant_p(mode)) {
      check_valid_analog_ref(mode);
    }
    _SWAP(mode);
    mode &= 0x07;
    uint8_t temp = VREF.DAC0REF & ~VREF_REFSEL_gm;
    temp |= mode;
    VREF.DAC0REF = temp;
  }
  uint8_t getDACReference() {
    uint8_t r = VREF.DAC0REF & VREF_REFSEL_gm;
    return _adcref_to_c(r); //convert native representation back into compound representation containing the settinf for both AC and ADC so that we don't have two sets of constants that need to be used depending on
  }
#else /* else no dac */
  void DACReference(__attribute__ ((unused))uint8_t mode) {
    badCall("DACreference is not available - this part does not have a DAC.");
  }
  uint8_t getDACReference() {
    badCall("This part does not have a DAC, it thus has no DAC reference.");
    return -1;
  }

#endif
/*----------------------------------------------------------------------------
 * Core ADC functionality implementations
 *----------------------------------------------------------------------------
 * Because the 2-series ADC is so radically different from the 0/1-series
 * (and, for that matter, just about everything else), it was most efficient
 * to separate out the core of the ADC stuff, where the viable shared code was
 * virtually nothing, and put it all in one part of the file, rather than the
 * normal practice of having the function defined in one place but with the
 * parts that are different controlled by #if's. Here, almost every line is
 * different!
 *
 * The only other time this has happened in the history of the AVR instruction
 * set, with any perpheral, is when the modern/AVRxt parts were introduced...
 * I hope we're not heading for total rewrites being required every few years.
 * I think this is just a transitional state; I couldn't see how to scale the
 * ADC like the AVR Dx-series has to something with this level of capability
 * either.
 *
 * ----------------------------------------------------------------------------
 * Functions:
 *
 * int16_t analogRead(uint8_t pin)
 *     The standard analogRead(). Single-ended, and resolution set by
 *     analogReadResolution(), default 10.
 *     large negative values are returned in the event of an error condition.
 *
 * bool analogReadResolution(uint8_t resolution)
 *     Sets resolution for the analogRead() function. Unlike stock version,
 *     this returns true/false. If it returns false, the value passed was
 *     invalid, and resolution is set to the default, 10 bits.
 *     ONLY 8, 10 and 12 (for 2-series only) are valid. To use
 *     any other value, you must use analogReadEnh(). The way iut is done on
 *     the Zero/Due/Etc is 1) wasteful of limited resources, and 2) dishonest
 *     because when you ask for a resolution it can't provide, it will lie and
 *     pad the value with zeros.
 * bool analogSampleDuration(uint8_t dur)
 *     Sets sampling duration (SAMPLEN on 0/1 or SAMPDUR on 2-series)
 *     For high impedance voltage sources, use a longer sample length.
 *     For faster reads, use a shorter sample length. Passing 0 will
 *     approximately double analogRead() speed.
 *     Returns true if value is valid; on 0/1-series maximum is 31 (33 ADC clock
 *     sampling duration); on 2-series any 8-bit value is valid, and duration is
 *     this many plus 0.5 (without PGA) or 1 (with PGA) ADC clocks.
 *     ADC clock targeted by default at startup is 1~1.25 MHz on 0/1, and ~2 MHz on 2-series.
 * uint8_t getAnalogSampleDuration()
 *     Trivial macro (located in Arduino.h). Returns the argument that you would pass to
 *     analogSampleDuration to get the current setting back (useful before
 *     changing it to something exotic)
 * void ADCPowerOptions(uint8_t options)
    // 0b SSEEPPLL
    // SS = run standby
    // 00 = no change to run standby
    // 01 = no change to run standby
    // 10 = turn off run standby
    // 11 = turn on run standby

    // EE = ENABLE
    // 00 = Do not enable or disable ADC.
    // 01 = Do not enable or disable ADC.
    // 10 = Disable the ADC.
    // 11 = Enable the ADC.

    // LL = LOWLAT
    // 00 = Do nothing.  No change to whether ADC enabled or LOWLAT bit.
    // 01 = Do nothing.  No change to whether ADC enabled or LOWLAT bit.
    // 10 = LOWLAT on. No change to whether ADC enabled.
    // 11 = LOWLAT off. No change to whether ADC enabled.
    // PP = PGA stay-on
    // 00 = No action
    // 01 = Turn off PGA, settings unchanged. It will be enabled next time is requested, but will not automatically turn off.
    // 10 = Turn on PGA, and don't turn it off automatically.
    // 11 = turn off PGA now and automatically after each use

 * int32_t analogReadEnh(uint8_t pin, int8_t res = ADC_NATIVE_RESOLUTION,
 *                                                          uint8_t gain = 0)
 *     Enhanced analogRead(). Still single-ended, res is resolution in bits,
 *     which range from 8 to the largest value that can be obtained from using
 *     the accumulation feature and a single "start" command to oversample x4
 *     per extra bit, followed by decimation/2 per extra bit (the math is
 *     described in Microchip/Atmel app notes). This maximum is 13 bits for
 *     0/1-series parts, and 17 bits for 2-series parts.
 *     Alternately, to get the raw accumulated ADC readings, pass one of the
 *     ADC_ACC_n constants for the second argument where n is a power of 2 up
 *     to 64 (0/1-series) 128 (Dx-series) or 1024 (2-series).
 *     On 2-series (but not Dx-series parts, which don't have a PGA) the PGA
 *     can be used. I was shocked when I saw that the PGA could be used with
 *     single-ended reads too, but they explicitly state that. Valid options
 *     for gain are 0 (PGA disabled), 1 (unity gain, but can improve performance
 *     of burst reads under some circumstances, and powers of 2 up to 16)
 * int32_t analogReadDiff(uint8_t pos, uint8_t neg,
 *                      int8_t res = ADC_NATIVE_RESOLUTION, uint8_t gain = 0)
 *     Uses the differential ADC functionality to take a differential ADC
 *     measurement between the specified positive and negative pins. Only pins
 *     on PORTA (tinyAVR 2-series) or on PORTD/PORTE (AVR Dx-series) can be the
 *     negative input to the ADC
 *     res works the same as for analogReadEnh.
 *     gain specifies that the programmable gain amplifier should be used.
 *     If gain = 0, the PGA will not be used. Valid options are 1, 2, 4, 8
 *     or 16 to configure the PGA to amplify by that factor.
 *
 *----------------------------------------------------------------------------
 * Errors:
 * analogReadEnh() or analogReadDiff() can return:
 *   ADC_ENH_ERROR_BAD_PIN_OR_CHANNEL (-2100000000)
 *     The selected pin has no analog input capability, does not exist,
 *     or, if it's a channel number (from ADC_CH(channel number), it
 *     does not exist or is otherwise invalid.
 *   ADC_ENH_ERROR_BUSY (-2100000001)
 *     Not yet enabled - will be an optional error in future update, maybe.
 *     The ADC is already taking a reading - either in free-running mode
 *     or through some user-implemented interrupt driven ADC routine.
 *   ADC_ENH_ERROR_INVALID_SAMPLE_LENGTH (-2100000002)
 *     Not yet enabled - will be an optional error in future update, maybe.
 *     On the 0/1-series parts, if sample length is specified, it must be
 *     below 0x1F (only 5 bits are used). That corresponds to 33 ACD clocks
 *     On the 2-series parts, this error is never returned, because all
 *     values between 0 and 255, inclusive, are valid.
 *     Currently, instead of returning an error, this will just set sample
 *     length to the maximum supported value.
 *   ADC_ENH_ERROR_RES_TOO_LOW (-2100000003)
 *     Resolution must not be lower than the lowest native resolution that
 *     the part supports (Core presents this as ADC_NATIVE_RESOLUTION_LOW)
 *     Get 8-bits and divide it if this is required; this is a rare
 *     use-case, and it is not appropriate to force the overhead on
 *     everyone else.
 *   ADC_ENH_ERROR_RES_TOO_HIGH (-2100000004)
 *    The 0/1-series can get 3 extra bits by oversampling 64x and right-
 *    shifting 3 times. The 2-series can get 5 by oversampling by a whopping
 *    1024x (taking 13-160 ms depending on options) and then right-shifting
 *    5 times. Thus, maximums are 13 and 17. Alternately, one of the
 *    ADC_ACC_n constants may be used, where n is 2, 4, 8, 16, 32, 64, or
 *    on 2-series only, 128, 256, 512, or 1024 - in this case, that many
 *    samples will be taken through burst/accumulation mode and returned
 *    without decimation.
 * analogReadDiff() can also return:
 *   ADC_ENH_ERROR_BAD_NEG_PIN (-2100000005)
 *    Returned by analogReadDiff when the requested pin for the negative
 *    input is not valid. Negative pins can only be on PORTA (for tinyAVR)
 *    or PORTD/PORTE (for Dx-series), and the selection of available
 *    channels is more limited.
 *
 * printADCRuntimeError(uint32_t error, &HardwareSerial DebugSerial)
 *   Prints a text description of an error returnedby analogRead,
 *   analogReasdEnh(),or analogReadDiff() to the specified serial device
 *   Ex:
 *    printADCRuntimeError(-2100000003, &Serial);
 *    will print "ADC_ENH_ERROR_RES_TOO_LOW"
 *    Will print nothing and return false if the result wasn't an error
 *   This function is not an efficient user of flash space, it is meant as a
 *   debugging aid.
 * analogIsError(int16_t from analogRead or int32_t from analogReadEnh)
 *   Returns 1 (true) if the value, assuming it came from an analogRead/Enh
 *   function call, is not an analog reading but instead an error code.
 ****************************************************************************/
#if defined(ADC0_TEMP2)  /* IMPORTANT IFDEF START NEW GOOD ADC */
    /*######    ###          ## ######## ########        ## ########  ######
    ##         ## ##        ##  ##       ##     ##      ##  ##       ##    ##           ##
    ##        ##   ##      ##   ##       ##     ##     ##   ##       ##                 ##
    ######   ##     ##    ##    ######   ########     ##    ######   ##              #  ##  #
    ##       #########   ##     ##       ##     ##   ##     ##       ##               # ## #
    ##       ##     ##  ##      ##       ##     ##  ##      ##       ##    ##          ####
    ######## ##     ## ##       ######## ########  ##       ########  ######            */
  #define SINGLE_ENDED 254

  static uint8_t _analog_options = 0x80 | 10;

  // need a variable to store the resolution selected for analogRead - 8, 10, or 12,
  // as well as other options, such as whether to autodisable the PGA or leave it running.
  // Default resolution 10 bits, turn off PGA enabled
  // decoded as 0bPxxxRRRR
  // RRRR = resolution, 8, 10, or 12
  // P = 1 for PGA auto-shutoff.
  // C = 1 to chop signs. Sign chopping can only be used on Series and Burst measurements
  // (this includes analogReadEnh() if you specify a resolution that triggers oversampling and
  // decimation). But when enabled appropriately, it will swap the positive and negative
  // pins on successive measurements. The result is, especially when measuring very small differences
  // with a large gain and low reference, much smaller offset error.
  // Sign Chopping support is not yet implemented, but this is how it will be.
  // Unless we determine that we can just leave it on and have it only use it for
  // the burst/series modes (in which case, it will probably be made the default)
  // we will turn it on in analogReadEnh/Diff (_analogReadEnh() specifically)
  // and then turn it off before returning, when we restore other ADC settings.


/* Ex Version*/
  inline bool analogReadResolution(uint8_t res) {
    check_valid_resolution(res);
      bool temp = (res == 8 || res == 10 || res == 12);
      _analog_options = (_analog_options & 0xF0) | (temp ? res : 10); // just set that variable. The new ADC only wants to be told the resolution when it starts a conversion
      return temp;
  }

/* Ex Version*/
  int8_t getAnalogReadResolution() {
    return _analog_options & 0x0F;
  }

  /* Ex Version*/
  void analogReference(uint8_t mode) {
    check_valid_analog_ref(mode);
    if (mode > 7)
      mode &= 7;
    if (mode != 1 && mode != 3) {
      ADC0.CTRLC = mode;
    }
  }
/* Ex Version*/
  inline uint8_t getAnalogReference() {
    uint8_t r = ADC0.CTRLC & ADC_REFSEL_gm;
    return _adcref_to_c(r); //convert native representation back into compound representation containing the settinf for both AC and ADC so that we don't have two sets of constants that need to be used depending on
  }
/* Ex Version*/
  int16_t analogRead(uint8_t pin) {
    check_valid_analog_pin(pin);
    if (pin < 0x80) {
      // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
      pin = digitalPinToAnalogInput(pin);
    } else {
      pin &= 0x3F;
    }
    #if PROGMEM_SIZE < 8096
      if (pin > 0x33) { // covers most ways a bad channel could come about
    #else
      if (pin > NUM_ANALOG_INPUTS && ((pin < 0x30) || (pin > 0x33))) {
    #endif
      return ADC_ERROR_BAD_PIN_OR_CHANNEL;
    }
    if (!ADC0.CTRLA & 0x01) return ADC_ERROR_DISABLED;

    if (ADC0.COMMAND & ADC_START_gm) return ADC_ERROR_BUSY;
    // gotta be careful here - don't want to shit ongoing conversion - unlikle classic AVRs
    // they say there is no buffering here!
    /* Select channel */
    ADC0.MUXPOS = pin; // VIA bit = 0;
    uint8_t command = (_analog_options & 0x0F) > 8 ? 0x11 : 0x01;
    /* Start conversion */
    ADC0.COMMAND = command;

    /* Wait for result ready */
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    // if it's 10 bit compatibility mode, have to rightshift twice.
    if ((_analog_options & 0x0F) == 10) {
      int16_t temp = ADC0.RESULT;
      temp >>= 2;
      return temp;
    }
    return ADC0.RESULT;
  }

/* Ex Version*/
  inline __attribute__((always_inline)) void check_valid_negative_pin(uint8_t pin) {
    if (__builtin_constant_p(pin)) {
      if (pin < 0x80) {
        // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
        pin = digitalPinToAnalogInput(pin);
      }
      pin &= 0x3F;
      if (pin != 0x33 && pin != 0x31 && pin != 0x30 && pin > 0x07) {
        badArg("Invalid negative pin - valid options are ADC_GROUND, ADC_VDDDIV10, ADC_DACREF0, or any pin on PORTA.");
      }
    }
  }
  bool analogSampleDuration(uint8_t sampdur) {
    // any uint8_t is a legal value...
    ADC0.CTRLE = sampdur;
    return true;
  }
  uint8_t getAnalogSampleDuration() {
    return ADC0.CTRLE;
  }
  /*NYI
  uint8_t ADCOptions(uint8_t options) {
    // 0b____CCFF
    // FF = Freerunning mode
    // Note that in freerun mode the ADC cannot be used for analogRead, you need to either define an ISR, or poll status and read the register directly
    // 00 = do nothing.
    // 01 = stop current conversion (very useful in freerun mode)
    // 10 = turn off freerun
    // 11 = turn on freerun
    */
   /*TODO: Figure out what happens if you have sign chopping on when it's not available. Does it blow up everything? Or is it just ignored?
    return
  }
  */

/* Ex Version*/
  void ADCPowerOptions(uint8_t options) {
    uint8_t temp = ADC0.CTRLA; //performance.
    if (options & 0x02) {
      ADC0.CTRLA = 0; // hopwfully workaround lowlat errata by ensuring that everything is turned off.
      // and configuring lowlat mode.
      if (options & 0x01) {
        ADC0.CTRLA |=  ADC_LOWLAT_bm;
        temp |= ADC_LOWLAT_bm;
      } else {
        ADC0.CTRLA &= ~ADC_LOWLAT_bm;
        temp &= ~ADC_LOWLAT_bm;
      }
    }
    if (options & 0x20) {
      if (options & 0x10) {
        temp |= 1; // ADC on
      } else {
        temp &= 0xFE; // ADC off
      }
    }
    if (options & 0x80) {
      if (options & 0x40) {
        temp |= 0x80; // run standby
      } else {
        temp &= 0x7F; // no run standby
      }
    }
    ADC0.CTRLA = temp; //now we apply enable and standby, and lowlat has been turned on, hopefully that's good enough for the errata.
    if (options & 0x04) { // turn off PGA.
      ADC0.PGACTRL &= ~ADC_PGAEN_bm;
      if (options & 0x08)  {
        _analog_options &= 0x7F;
      } else {
        _analog_options |= 0x80;
      }
    } else { // not instruction to turn off PGA
      if (options & 0x08) { // is it in fact an instruction to turn on the PGA and leave it on?
        ADC0.PGACTRL |= ADC_PGAEN_bm; // turn on the PGA
        _analog_options &= 0x7F;      // turn off the auto-shutoff. If they told us to turn it on explicitly, surely they don't want us to turn it off of our own accord.
      }
    }
    // What a mess!
  }

/* Ex Version*/
  int32_t _analogReadEnh(uint8_t pin, uint8_t neg, uint8_t res, uint8_t gain) {
    if (!(ADC0.CTRLA & 0x01)) {return ADC_ENH_ERROR_DISABLED;}
    uint8_t sampnum;
    if (res > 0x80) { // raw accumulation
      sampnum = res & 0x7F;
      if (sampnum > 10) {return ADC_ENH_ERROR_RES_TOO_HIGH;}
    } else {
      if (res < ADC_NATIVE_RESOLUTION_LOW) {return ADC_ENH_ERROR_RES_TOO_LOW;}
      if (res > 17) {return ADC_ENH_ERROR_RES_TOO_HIGH;}
      sampnum = (res > ADC_NATIVE_RESOLUTION ? ((res - ADC_NATIVE_RESOLUTION) << 1) : 0);
    }

    if (pin < 0x80) {
      // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
      pin = digitalPinToAnalogInput(pin);
    } else {
      pin &= 0x3F;
    }
    #if PROGMEM_SIZE < 8096
      if (pin > 0x33) // covers most ways a bad channel could come about
    #else
      if (pin > NUM_ANALOG_INPUTS && ((pin < 0x30) || (pin > 0x33)))
    #endif
    {
      return ADC_ENH_ERROR_BAD_PIN_OR_CHANNEL;
    }
    if (neg != SINGLE_ENDED) {
      if (neg < 0x80) {
        // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
        neg = digitalPinToAnalogInput(neg);
      } else {
        neg &= 0x3F;
      }

      #if PROGMEM_SIZE < 8096
        if (neg > 0x33)  // covers most ways a bad channel could come about
      #else
        if (neg > NUM_ANALOG_INPUTS && ((neg != 0x30) && (neg != 0x33) && (neg != 0x31)))
      #endif
      {
        return ADC_DIFF_ERROR_BAD_NEG_PIN;
      }
      neg &= 0x3F;

    }
    pin &= 0x3F;

    if (ADC0.COMMAND & ADC_START_gm) return ADC_ENH_ERROR_BUSY;
    if (gain != 0) {
      uint8_t gainbits = 0;
      while (gain > 1) {
        gain >>= 1;
        gainbits+= 32;
      }
      ADC0.PGACTRL = (ADC0.PGACTRL & ~ADC_GAIN_gm) | gainbits | ADC_PGAEN_bm;
    }

    ADC0.MUXPOS = (gain ? ADC_VIA_PGA_gc:0) | pin;
    if (neg != SINGLE_ENDED) {
      ADC0.MUXNEG = (gain ? ADC_VIA_PGA_gc:0) | neg;
    }
    ADC0.CTRLF = sampnum;
    uint8_t command = ((neg != SINGLE_ENDED)?0x80:0) | ((res == 8) ? ADC_MODE_SINGLE_8BIT_gc : (res > ADC_NATIVE_RESOLUTION ? ADC_MODE_BURST_gc : ADC_MODE_SINGLE_12BIT_gc)) | 1;
    ADC0.COMMAND = command;
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    int32_t result = ADC0.RESULT;

    if (res < 0x80 && res > ADC_NATIVE_RESOLUTION) {
      uint8_t shift = res - ADC_NATIVE_RESOLUTION ; // - 1;
      while (shift) {
        result >>= 1;
        shift--;
      }
      // Sanity checks
      // uint8_t roundup = result&0x01;
      // result >>= 1;
      // result += roundup;
    } else if (res == 8) {
      ; // do nothing
    } else if (res < ADC_NATIVE_RESOLUTION) {
      uint8_t shift = ADC_NATIVE_RESOLUTION - res;
      result >>= shift;
    }

    // res > 0x80 (raw accumulate) or res == 8, res == 12 need no adjustment.
    if (_analog_options & 0x80) { // this bit controls autoshutoff of PGA.
      ADC0.PGACTRL &= ~ADC_PGAEN_bm;
    }
    return result;
  }
/* Ex Version*/
  inline int32_t analogReadEnh(uint8_t pin, uint8_t res, uint8_t gain) {
    check_valid_enh_res(res);
    check_valid_analog_pin(pin);
    if (__builtin_constant_p(gain)) {
      if (gain != 0 && gain != 1 && gain != 2 && gain != 4 && gain != 8 && gain != 16){
        badArg("The requested gain is not available on this part, accepted values are 0, 1, 2, 4, 8 and 16.");
      }
    }
    return _analogReadEnh(pin, SINGLE_ENDED, res, gain);
  }

  inline int32_t analogReadDiff(uint8_t pos, uint8_t neg, uint8_t res, uint8_t gain) {
    check_valid_enh_res(res);
    check_valid_analog_pin(pos);
    check_valid_negative_pin(neg);
    if (__builtin_constant_p(gain)) {
      if (gain != 0 && gain != 1 && gain != 2 && gain != 4 && gain != 8 && gain != 16){
        badArg("The requested gain is not available on this part, accepted values are 0, 1, 2, 4, 8 and 16.");
      }
    }
    return _analogReadEnh(pos, neg, res, gain);
  }

  static const PROGMEM int16_t adc_prescale_to_clkadc[0x11] =  {(F_CPU /  2000L),(F_CPU /  4000L),(F_CPU /  6000L),(F_CPU /  8000L),
  /* Doesn't get copied to ram because these all */     (F_CPU / 10000L),(F_CPU / 12000L),(F_CPU / 14000L),(F_CPU / 16000L),
  /* have fully memory mapped flash. Calculated  */     (F_CPU / 20000L),(F_CPU / 24000L),(F_CPU / 28000L),(F_CPU / 32000L),
  /* at compile time (we get to use division!)   */     (F_CPU / 40000L),(F_CPU / 48000L),(F_CPU / 56000L),(F_CPU / 64000L),1};


  /*
  Frequency in kHz.
  If options & 1 == 1, will set frequencies outside of safe operating range
  Otherwise, will be constrained to between 300 and 3000 (if internal reference used) or 300 and 6000 if not.
  Note: analogReference does NOT check this! So set the clock speed after reference if you want that guardrail.
  0 takes action, and -1 sets to default.
  */
  int16_t analogClockSpeed(int16_t frequency, uint8_t options) {
    if (frequency == -1) {
      frequency = 2750;
    }
    if (frequency > 0) {
      if ((options & 0x01) == 0) {
        frequency = constrain(frequency, 300, ((ADC0.CTRLC & 0x04) ? 3000 : 6000));
      }
      uint8_t prescale = 0;
      for (uint8_t i = 0; i < 16; i++) {
        int16_t clkadc = pgm_read_word_near(&adc_prescale_to_clkadc[i]);
        prescale = i;
        if ((frequency >= clkadc) ||  pgm_read_word_near(&adc_prescale_to_clkadc[i + 1]) < ((options & 0x01) ? 2 : 300)) {
          ADC0.CTRLB = prescale;
          break;
        }
      }
    }
    if (frequency < 0) {
      return ADC_ERROR_INVALID_CLOCK;
    }
    return pgm_read_word_near(&adc_prescale_to_clkadc[ADC0.CTRLB]);
  }



      /*           ########  ##     ##          ##
      ##           ##     ## ##     ##          ##
      ##           ##     ## ##     ##          ##
   #  ##  #        ##     ## ##     ##       #  ##  #
    # ## #         ##     ## ##     ##        # ## #
     ####          ##     ## ##     ##         ####
      ##           ########   #######           */


  #elif defined(ADC_LOWLAT_bm) /* MAJOR IMPORTANT ELIF CONDITIONAL */
  // only the good ADC has the larger temp register, and we're testing this if we don't have the larger register.
  static uint8_t _analog_options = 0x80 | 10;

  #define SINGLE_ENDED 254
  inline bool analogReadResolution(uint8_t res) {
    check_valid_resolution(res);
      bool temp = (res == 8 || res == 10);
      _analog_options = (_analog_options & 0xF0) | (temp ? res : 10); // just set that variable. The new ADC only wants to be told the resolution when it starts a conversion
      return temp;
  }
  int8_t getAnalogReadResolution() {
    return _analog_options & 0x0F;
  }
  void analogReference(uint8_t mode) {
    check_valid_analog_ref(mode);
    #if defined(STRICT_ERROR_CHECKING)
      if (mode > 7) return;
    #else
      mode &= 7;
    #endif
    if (mode != 1 && mode != 3) {
      ADC0.CTRLC = mode;
    }
    // Uh? Is that it? That was, ah, a tiny bit simpler.
  }
  inline uint8_t getAnalogReference() {
    uint8_t r = ADC0.CTRLC & ADC_REFSEL_gm;
    return _adcref_to_c(r); //convert native representation back into compound representation containing the settinf for both AC and ADC so that we don't have two sets of constants that need to be used depending on
  }

  int16_t analogRead(uint8_t pin) {
    check_valid_analog_pin(pin);
    if (pin < 0x80) {
      // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
      pin = digitalPinToAnalogInput(pin);
    } else {
      pin &= 0x3F;
    }
    #if PROGMEM_SIZE < 8096
      if (pin > 0x33) { // covers most ways a bad channel could come about
    #else
      if (pin > NUM_ANALOG_INPUTS && ((pin < 0x30) || (pin > 0x33))) {
    #endif
      return ADC_ERROR_BAD_PIN_OR_CHANNEL;
    }
    if (!ADC0.CTRLA & 0x01) return ADC_ERROR_DISABLED;

    if (ADC0.COMMAND & ADC_START_gm) return ADC_ERROR_BUSY;
    // gotta be careful here - don't want to shit ongoing conversion - unlikle classic AVRs
    // they say there is no buffering here!
    /* Select channel */
    ADC0.MUXPOS = pin; // VIA bit = 0;
    uint8_t command = (_analog_options & 0x0F) > 8 ? 0x11 : 0x01;
    /* Start conversion */
    ADC0.COMMAND = command;

    /* Wait for result ready */
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    // if it's 10 bit compatibility mode, have to rightshift twice.
    if ((_analog_options & 0x0F) == 10) {
      int16_t temp = ADC0.RESULT;
      temp >>= 2;
      return temp;
    }
    return ADC0.RESULT;
  }


  inline __attribute__((always_inline)) void check_valid_negative_pin(uint8_t pin) {
    if (__builtin_constant_p(pin)) {
      if (pin != SINGLE_ENDED) {
        // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
        pin = digitalPinToAnalogInput(pin);
      }
      pin &= 0x3F;
      if (pin != 0x33 && pin != 0x31 && pin != 0x30 && pin > 0x07) {
        badArg("Invalid negative pin - valid options are ADC_GROUND, ADC_VDDDIV10, ADC_DACREF0, or any pin on PORTA.");
      }
    }
  }
  bool analogSampleDuration(uint8_t sampdur) {
    // any uint8_t is a legal value...
    ADC0.CTRLE = sampdur;
    return true;
  }
  uint8_t getAnalogSampleDuration() {
    return ADC0.CTRLE;
  }
  /*
  uint8_t ADCOptions(uint8_t options) {
    // 0b____CCFF
    // FF = Freerunning mode
    // Note that in freerun mode the ADC cannot be used for analogRead, you need to either define an ISR, or poll status and read the register directly
    // 00 = do nothing.
    // 01 = stop current conversion (very useful in freerun mode)
    // 10 = turn off freerun
    // 11 = turn on freerun
    */
   /*TODO: Figure out what happens if you have sign chopping on when it's not available. Does it blow up everything? Or is it just ignored?
    return
  }
  */

  void ADCPowerOptions(uint8_t options) {
    uint8_t temp = ADC0.CTRLA; //performance.
    if (options & 0x02) {
      ADC0.CTRLA = 0; // hopwfully workaround lowlat errata by ensuring that everything is turned off.
      // and configuring lowlat mode.
      if (options & 0x01) {
        ADC0.CTRLA |=  ADC_LOWLAT_bm;
        temp |= ADC_LOWLAT_bm;
      } else {
        ADC0.CTRLA &= ~ADC_LOWLAT_bm;
        temp &= ~ADC_LOWLAT_bm;
      }
    }
    if (options & 0x20) {
      if (options & 0x10) {
        temp |= 1; // ADC on
      } else {
        temp &= 0xFE; // ADC off
      }
    }
    if (options & 0x80) {
      if (options & 0x40) {
        temp |= 0x80; // run standby
      } else {
        temp &= 0x7F; // no run standby
      }
    }
    ADC0.CTRLA = temp; //now we apply enable and standby, and lowlat has been turned on, hopefully that's good enough for the errata.
    // What a mess!
  }


  int32_t _analogReadEnh(uint8_t pin, __attribute__ ((unused)) uint8_t neg, uint8_t res, __attribute__ ((unused)) uint8_t gain) {
    if (!(ADC0.CTRLA & 0x01)) return ADC_ENH_ERROR_DISABLED;
    uint8_t sampnum;
    if (res > 0x80) { // raw accumulation
      sampnum = res & 0x7F;
      if (sampnum > 10) return ADC_ENH_ERROR_RES_TOO_HIGH;
    } else {
      if (res < ADC_NATIVE_RESOLUTION_LOW) return ADC_ENH_ERROR_RES_TOO_LOW;
      if (res > 17) return ADC_ENH_ERROR_RES_TOO_HIGH;
      sampnum = (res > ADC_NATIVE_RESOLUTION ? ((res - ADC_NATIVE_RESOLUTION) << 1) : 0);
    }

    if (pin < 0x80) {
      // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
      pin = digitalPinToAnalogInput(pin);
    } else {
      pin &= 0x3F;
    }
    #if PROGMEM_SIZE < 8096
      if (pin > 0x33)  // covers most ways a bad channel could come about
    #else
      if (pin > NUM_ANALOG_INPUTS && ((pin < 0x30) || (pin > 0x33)))
    #endif
    {
      return ADC_ENH_ERROR_BAD_PIN_OR_CHANNEL;
    }
    pin &= 0x3F;

    if (ADC0.COMMAND & ADC_START_gm) return ADC_ENH_ERROR_BUSY;


    ADC0.MUXPOS =  pin;

    ADC0.CTRLF = sampnum;
    uint8_t command = ((res == 8) ? ADC_MODE_SINGLE_8BIT_gc : (res > ADC_NATIVE_RESOLUTION ? ADC_MODE_BURST_gc : ADC_MODE_SINGLE_10BIT_gc)) | 1;
    ADC0.COMMAND = command;
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    int32_t result = ADC0.RESULT;

    if (res < 0x80 && res > ADC_NATIVE_RESOLUTION) {
      uint8_t shift = res - ADC_NATIVE_RESOLUTION ; // - 1;
      while (shift) {
        result >>= 1;
        shift--;
      }
      // Sanity checks
      // uint8_t roundup = result&0x01;
      // result >>= 1;
      // result += roundup;
    } else if (res == 8) {
      ; // do nothing
    } else if (res < ADC_NATIVE_RESOLUTION) {
      uint8_t shift = ADC_NATIVE_RESOLUTION - res;
      result >>= shift;
    }

    // res > 0x80 (raw accumulate) or res == 8, res == 12 need no adjustment.

    return result;
  }

  inline int32_t analogReadEnh(uint8_t pin, uint8_t res, __attribute__((unused)) uint8_t gain) {
    check_valid_enh_res(res);
    check_valid_analog_pin(pin);
    if (__builtin_constant_p(gain)) {
      if (gain != 0) {
        badArg("Gain is not available on the AVR DU-series");
      }
    }
    return _analogReadEnh(pin, SINGLE_ENDED, res, 0);
  }

  inline int32_t analogReadDiff(__attribute__((unused)) uint8_t pos, __attribute__((unused)) uint8_t neg, __attribute__((unused)) uint8_t res, __attribute__((unused)) uint8_t gain) {
    badCall("The AVR DU-series is not equipped with a differential ADC.");
    return 0xFFFFFFFF; // Can't happen, code that can execute this won't compile
  }

  static const PROGMEM int16_t adc_prescale_to_clkadc[0x11] =  {(F_CPU /  2000L),(F_CPU /  4000L),(F_CPU /  6000L),(F_CPU /  8000L),
  /* Doesn't get copied to ram because these all */     (F_CPU / 10000L),(F_CPU / 12000L),(F_CPU / 14000L),(F_CPU / 16000L),
  /* have fully memory mapped flash. Calculated  */     (F_CPU / 20000L),(F_CPU / 24000L),(F_CPU / 28000L),(F_CPU / 32000L),
  /* at compile time (we get to use division!)   */     (F_CPU / 40000L),(F_CPU / 48000L),(F_CPU / 56000L),(F_CPU / 64000L),1};


  /*
  Frequency in kHz.
  If options & 1 == 1, will set frequencies outside of safe operating range
  Otherwise, will be constrained to between 300 and 3000 (if internal reference used) or 300 and 6000 if not.
  Note: analogReference does NOT check this! So set the clock speed after reference if you want that guardrail.
  0 takes action, and -1 sets to default.
  */
  int16_t analogClockSpeed(int16_t frequency, uint8_t options) {
    if (frequency == -1) {
      frequency = 2750;
    }
    if (frequency > 0) {
      if ((options & 0x01) == 0) {
        frequency = constrain(frequency, 300, ((ADC0.CTRLC & 0x04) ? 3000 : 6000));
      }
      uint8_t prescale = 0;
      for (uint8_t i = 0; i < 16; i++) {
        int16_t clkadc = pgm_read_byte_near(&adc_prescale_to_clkadc[i]);
        prescale = i;
        if ((frequency >= clkadc) || (adc_prescale_to_clkadc[i + 1] < ((options & 0x01) ? 2 : 300))) {
          ADC0.CTRLB = prescale;
          break;
        }
      }
    }
    if (frequency < 0) {
      return ADC_ERROR_INVALID_CLOCK;
    }
    return adc_prescale_to_clkadc[ADC0.CTRLB];
  }






#else /* SUPER IMPORTANT PREPROCESSOR DIRECTIVE */
    // Otherwise it's a DX that isn't a DU.
   /*######     ###          ## ########  ########        ## ########  ########           ##
   ##     ##   ## ##        ##  ##     ## ##     ##      ##  ##     ## ##     ##          ##
   ##     ##  ##   ##      ##   ##     ## ##     ##     ##   ##     ## ##     ##          ##
   ##     ## ##     ##    ##    ##     ## ########     ##    ##     ## ##     ##       #  ##  #
   ##     ## #########   ##     ##     ## ##     ##   ##     ##     ## ##     ##        # ## #
   ##     ## ##     ##  ##      ##     ## ##     ##  ##      ##     ## ##     ##         ####
   ########  ##     ## ##       ########  ########  ##       ########  ########           */

  void analogReference(uint8_t mode) {
    check_valid_analog_ref(mode);
    if (mode < 7 && mode != 4) {
      VREF.ADC0REF = (VREF.ADC0REF & ~(VREF_REFSEL_gm))|(mode);
    }
  }

  int16_t analogRead(uint8_t pin) {
    check_valid_analog_pin(pin);
    if (pin < 0x80) {
      pin = digitalPinToAnalogInput(pin);
      if (pin == NOT_A_PIN) {
        return ADC_ERROR_BAD_PIN_OR_CHANNEL;
      }
    }
    /* Select channel */
    ADC0.MUXPOS = ((pin & 0x7F) << ADC_MUXPOS_gp);
    /* Reference should be already set up */

    /* Start conversion */
    ADC0.COMMAND = ADC_STCONV_bm;

    /* Wait for result ready */
    while(!(ADC0.INTFLAGS & ADC_RESRDY_bm));

    #if (defined(__AVR_DA__) && (!defined(NO_ADC_WORKAROUND)))
      // That may become defined when DA-series silicon is available with the fix
      ADC0.MUXPOS = 0x40;
    #endif
    return ADC0.RES;
  }


  inline __attribute__((always_inline)) void check_valid_negative_pin(uint8_t pin) {
    if(__builtin_constant_p(pin)) {
      if (pin < 0x80) {
        // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
        pin = digitalPinToAnalogInput(pin);
      }
      pin &= 0x3F;
      if (pin != 0x40 && pin != 0x48 && pin > 0x0F) { /* Not many options other than pins are valid */
        badArg("Invalid negative pin - valid options are ADC_GROUND, ADC_DAC0, or any pin on PORTD or PORTE.");
      }
    }
  }

  bool analogSampleDuration(uint8_t dur) {
      ADC0.SAMPCTRL = dur;
      return true;
  }


  int32_t _analogReadEnh(uint8_t pin, uint8_t neg, uint8_t res, __attribute__ ((unused)) uint8_t gain) {
    /* Combined implementation for enhanced and differential ADC reads. Gain is ignored, these have no PGA.
     * However, note that if the user passed a constant gain argument, which is what almost anyone would
     * do, THAT would be a compile error. Only deviant code that dynamically determines the gain and
     * neglects to verify that the part in question has a PGA can end up in a situation where code may
     * think it is getting gain applied, but none is. I will ensure that it is documented that any code
     * that runs as part of a library or is shared with others, and which calls either of these analogRead____
     * functions with a non-zero gain, it is the responsibility of that code to verify that it is being
     * used on a system with gain available.
     * Can be split into 4 phases:
     *  1. Process input parameters, detect error conditions that couldn't be caught at compile-time.
     *  2. Apply settings and take reading - MUXPOS, MUXNEG, CTRLA, CTRLB registers are involved
     *    We want the user to be successful, so backup and restore the two registers that don't get
     *    rewritten every time the ADC is used anyway.
     *  3. Process the reading we took if needed - decimate where decimation is required and shift as
     *    as appropriate when the user has requested less than 12 bits of resolution.
     *  4. Restore registers we modified amd return results.
     */

    /*******************************
     *  Phase 1: Input Processing  |
     ******************************/
    if (!(ADC0.CTRLA & 0x01)) return ADC_ENH_ERROR_DISABLED;
    // 5/16 - uhhhh if it's disabled, maybe we should re-enable it, take the reading, and our cleanup will turn it off again...
    //        Could lead to difficult to debug performance issues though, whereas this would tell them
    //        the minute they tried to that they had the ADC off. The startup time of the ADC is not negligible in many applications.
    uint8_t sampnum;
    if (res & 0x80) {           // raw accumulation
      sampnum = res & 0x7F;       // strip high bit and treat as negative number
      if (sampnum > 7)  return  ADC_ENH_ERROR_RES_TOO_HIGH; //
    } else {
      if (res < 8)                              return   ADC_ENH_ERROR_RES_TOO_LOW;
      if (res > ADC_MAX_OVERSAMPLED_RESOLUTION) return  ADC_ENH_ERROR_RES_TOO_HIGH;
      sampnum = (res > ADC_NATIVE_RESOLUTION ? ((res - ADC_NATIVE_RESOLUTION) << 1) : 0);
    }
    if (pin < 0x80) {
      // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
      pin = digitalPinToAnalogInput(pin);
    }
    else pin &= 0x7F;
    if (pin > 0x4B || (pin > ADC_MAXIMUM_PIN_CHANNEL &&  pin < 0x40))  {
      /*  If it's over 0x4B, it's not a valid option.
          If it's higher than the highest analog channel number, and lower than the start of internal sources, it's not valid.
          This does not check for internal sources that don't exist (all valid internal sources are checked for in the case of compile-time-known pins)
            Not worth wasting on the scale of 20-some-odd bytes of flash just to give an error to people who dynamically generate invalid analog pins
            and try to use them with analogReadEnh(), instead of just returning whatever we get from reading the bogus channel */
      return ADC_ENH_ERROR_BAD_PIN_OR_CHANNEL;
    }
    if (ADC0.COMMAND & ADC_STCONV_bm) {
      return ADC_ENH_ERROR_BUSY;
    /*  Doing the busy check up here so that if we are doing differential read, we
        find out before calculating MUXNEG, which we can now assign as soon as calculated..
        Otherwise, we'd have to check busy-ness, then if it was a differential reading, set MUXNEG. */
    }
    if (neg != SINGLE_ENDED) {
      if (neg < 0x80) {
        // If high bit set, it's a channel, otherwise it's a digital pin so we look it up..
        neg = digitalPinToAnalogInput(neg);
      } else {
        neg &= 0x3F;
      }
      if (neg > ADC_MAXIMUM_NEGATIVE_PIN && neg != 0x40 &&  pin != 0x48)  {
        // Not all pins are valid as negative side of differential ADC measurements.
        // On DA and DB, the last ADC channel is 21 (0x15).  DD goes up to 31 (0x1F)
        return ADC_DIFF_ERROR_BAD_NEG_PIN;
      }
      ADC0.MUXNEG = neg;
      /*  OK to do since we have verified that it's not in mid-conversion. That doesn't
          explicitly break anything to change it during conversion, but it would change
          the channel, then determine that it could not take the measurement and return
          the error (unlike the ADC on the tinyAVR 2-series where the datasheet says you
          can change the channel during a conversion and corrupt the results). But, if
          it was busy because it was in free running mode, though, this would change the
          channel used for subsequent reads. That is why we check that the ADC is not
          busy before entering this block. */
    } // end neg != SINGLE_ENDED
    /********************************************
     *  Phase 2: Configure ADC and take reading  |
     ********************************************/
    ADC0.MUXPOS = pin;
    uint8_t _ctrlb = ADC0.CTRLB;
    uint8_t _ctrla = ADC0.CTRLA;
    ADC0.CTRLA = ADC_ENABLE_bm | (res == ADC_NATIVE_RESOLUTION_LOW ? ADC_RESSEL_10BIT_gc : 0) | (neg == SINGLE_ENDED ? 0 : ADC_CONVMODE_bm);
    ADC0.CTRLB = sampnum;

    ADC0.COMMAND = ADC_STCONV_bm;
    while (!(ADC0.INTFLAGS & ADC_RESRDY_bm));
    int32_t result = ADC0.RES; // This should clear the flag
    /******************************
     *  Phase 3: Post-processing  |
     *****************************/
    if (res < 0x80 && res != ADC_NATIVE_RESOLUTION && res != ADC_NATIVE_RESOLUTION_LOW) { /* Result needs to be decimated or divided */
      // Logic more complicated here vs megaTinyCore because we have to contend with the fact that truncation has already occurred.
      if (res > ADC_NATIVE_RESOLUTION) {
        uint8_t resbits = res * 2 - ADC_NATIVE_RESOLUTION;
        // The number of bits of resolution we would be getting and need to decimate if there was no truncation.
        // result length in bits, but count the bits beyond native resolution twice, since each one needs a bit of decimation.
        uint8_t shift = res - ADC_NATIVE_RESOLUTION;
        // but if it exceeds 16 bits it gets truncated
        // Effectively there are three possible oversampling values: 13, 14, and 15, and they need 1, 2, amd 1 shift, respectively.
        if (resbits > 16) {
          shift -= (resbits - 16); // these "shifts" were already done for us by the hardware to make the number in the result register.
        }
        while (shift) {
          result >>= 1;
          shift--;
        }

      } else if (res == 8) {
        result >>= 2;
      } else { //((res == ADC_NATIVE_RESOLUTION - 1) || (res == ADC_NATIVE_RESOLUTION_LOW - 1))
        // 9 or 11 bit res, because people are weird and might do this
        result >>= 1;
      }
    } // end of resolutions that require postprocessing.

    /*******************************
     *  Phase 4: Cleanup + Return  |
     ******************************/
    #if (defined(ERRATA_ADC_PIN_DISABLE) && ERRATA_ADC_PIN_DISABLE != 0)
      // That may become defined when DA-series silicon is available with the fix
      ADC0.MUXPOS = 0x40;
    #endif
    ADC0.CTRLB = _ctrlb;      // the user having something set in CTRLB is not implausuble
    ADC0.CTRLA = _ctrla;      // undo the mess we just made in ADC0.CTRLA
    return result;
  }

  int32_t analogReadDiff(uint8_t pos, uint8_t neg, uint8_t res, uint8_t gain) {
    check_valid_enh_res(res);
    check_valid_analog_pin(pos);
    check_valid_negative_pin(neg);
    if (__builtin_constant_p(gain)){
      if (gain != 0) badArg("This part does not have an amplifier; gain must be 0 or omitted");
    }
    return _analogReadEnh(pos, neg, res, 0);
  }

  inline int32_t analogReadEnh(uint8_t pin, uint8_t res, uint8_t gain) {
    check_valid_enh_res(res);
    check_valid_analog_pin(pin);
    if (__builtin_constant_p(gain)) {
      if (gain != 0) badArg("This part does not have an amplifier; gain must be 0 or omitted");
    }
    return _analogReadEnh(pin,SINGLE_ENDED,res,0);
  }

  bool analogReadResolution(uint8_t res) {
    #if defined(STRICT_ERROR_CHECKING) /* not yet implemented, may be an optional error in a future version */
      if (!__builtin_constant_p(res)) {
        badArg("analogReadResolution should only be passed constant values");
      }
    #endif
    if (__builtin_constant_p(res)) {
      if (res != 10 && res != 12) {
        badArg("analogReadResolution called with invalid argument - valid options are 10 or 12.");
      }
    }
    if (res == 12) {
      ADC0.CTRLA = (ADC0.CTRLA & (~ADC_RESSEL_gm)) | ADC_RESSEL_12BIT_gc;
    } else {
      ADC0.CTRLA = (ADC0.CTRLA & (~ADC_RESSEL_gm)) | ADC_RESSEL_10BIT_gc;
      return (res == 10);
    }
    return true;
  }

  int8_t getAnalogReadResolution() {
    return ((ADC0.CTRLA & (ADC_RESSEL_gm)) == ADC_RESSEL_12BIT_gc) ? 12 : 10;
  }

  inline uint8_t getAnalogSampleDuration() {
    return ADC0.SAMPCTRL;
  }

  uint8_t getAnalogReference() {
    uint8_t r = VREF.ADC0REF & VREF_REFSEL_gm;
    return _adcref_to_c(r); //convert native representation back into compound representation containing the settinf for both AC and ADC so that we don't have two sets of constants that need to be used depending
  }


  /* Frequency in kHz. */
   static const int16_t adc_prescale_to_clkadc[0x0F] PROGMEM = {(F_CPU /   2000L),(F_CPU /   4000L),(F_CPU /  8000L),(F_CPU / 12000L),
                                                                (F_CPU /  16000L),(F_CPU /  20000L),(F_CPU / 24000L),(F_CPU / 28000L),
                                                                (F_CPU /  32000L),(F_CPU /  48000L),(F_CPU / 64000L),(F_CPU / 96000L),
                                                                (F_CPU / 128000L),(F_CPU / 256000L),1};


  int16_t analogClockSpeed(int16_t frequency, uint8_t options) {
    if (__builtin_constant_p(frequency)) {
      if (frequency < -1) {
        badArg("Acceptable arguments to analogClockSpeed are -1 (set to default value) 0 (no change) or a positive integer frequency (in kHz)");
      }
    }
    if (frequency == -1) {
      frequency = 1450;
    }
    if (frequency > 0 ) {
      if (!(options & 0x01)) {
        frequency = constrain(frequency, 125, 2000);
      }
      uint8_t newpresc = 0;
      while (((int16_t)pgm_read_word_near(&adc_prescale_to_clkadc[newpresc])> frequency) &&  newpresc < 8 && (pgm_read_word_near(&adc_prescale_to_clkadc[newpresc + 1]) > ((options & 0x01) ? 1 : 125) )) {
        newpresc++;
      }
      ADC0.CTRLC = newpresc;
      //uint16_t f = pgm_read_word_near(&adc_prescale_to_clkadc[newpresc]);

    } else if (frequency != 0) {
      return ADC_ERROR_INVALID_CLOCK;
    }
    return pgm_read_word_near(&adc_prescale_to_clkadc[ADC0.CTRLC & ADC_PRESC_gm]);
  }


/* options is 0bSSEE---- where SS and EE are either 10, 11, or 00 and - is don't care.
    SS controls RUNSTBY, EE controls ENABLE;
    0b11 turns the option on, 0b10 turns it off, and 0b00 leaves it in it's current setting */

  void ADCPowerOptions(uint8_t options) {
    uint8_t temp = ADC0.CTRLA; //performance.
    if (options & 0x20) {
      if (options & 0x10) {
        temp |= 1; // ADC on
      } else {
        temp &= 0xFE; // ADC off
      }
    }
    if (options & 0x80) {
      if (options & 0x40) {
        temp |= 0x80; // run standby
      } else {
        temp &= 0x7F; // no run standby
      }
    }
    ADC0.CTRLA = temp; //now we apply enable and standby, and lowlat has been turned on, hopefully that's good enough for the errata.
    // What a mess!
  }


#endif





/*#######       ###       ##
 ##     ##     ## ##     ####
 ##     ##    ##   ##   # ## #
 ##     ##   ##     ##    ##
 ##     ##   #########    ##
 ##     ##   ##     ##    ##
 ########    ##     ##    */







/*####### ##    ## ########        ###    ########   ######
 ##       ###   ## ##     ##      ## ##   ##     ## ##    ##
 ##       ####  ## ##     ##     ##   ##  ##     ## ##
 ######   ## ## ## ##     ##    ##     ## ##     ## ##
 ##       ##  #### ##     ##    ######### ##     ## ##
 ##       ##   ### ##     ##    ##     ## ##     ## ##    ##
 ######## ##    ## ########     ##     ## ########   #####*/








